package com.brillio.Favourites;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FavouritesMain {

	public static void main(String[] args) {
		SpringApplication.run(FavouritesMain.class, args);
	}

}
