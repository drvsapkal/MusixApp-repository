package com.brillio.Recommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecommendationMain {

	public static void main(String[] args) {
		SpringApplication.run(RecommendationMain.class, args);
	}
	
}
